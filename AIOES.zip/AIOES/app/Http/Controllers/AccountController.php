<?php

namespace App\Http\Controllers;
use Auth;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;

class AccountController extends Controller

{
   public function login() {
    // Getting all post data
    $data = Input::all();
    // Applying validation rules.
    $rules = array(
		'email' => 'required|email',
		'password' => 'required|min:6',
	     );
    $validator = Validator::make($data, $rules);
    if ($validator->fails()){
      // If validation falis redirect back to login.
      return Redirect::to('/')->withInput(Input::except('password'))->withErrors($validator);
    }
    else {
      $userdata = array(
		    'email' => Input::get('email'),
		    'password' => Input::get('password')
		  );
                //  print_r($userdata);exit;
      // doing login.
      if (Auth::validate($userdata)) {
        if (Auth::attempt($userdata))
            {
          return Redirect::intended('welcome');    
        }
      } 
      else {
        // if any error send back with message.
        Session::flash('error', 'Something went wrong'); 
        return Redirect::to('/');
      }
    }
  }
  
  public function logout() {
  Auth::logout(); // logout user
  return Redirect::to('/'); //redirect back to login
}
    
    
    
    
    
    
    
    
    
}
